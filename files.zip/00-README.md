# Plano de Implementação — API de Detecção de Domínios Maliciosos

Este conjunto de documentos descreve como implementar a API. Cada arquivo cobre um tópico e deve ser lido na ordem abaixo.

## Índice

| # | Arquivo | Conteúdo |
|---|---------|----------|
| 01 | `01-arquitetura-e-estrutura.md` | Visão geral, componentes, stack, estrutura de pastas |
| 02 | `02-modelo-de-dados-supabase.md` | Tabelas, SQL, RLS, índices (todos os ids UUID) |
| 03 | `03-autenticacao-e-otp.md` | Cadastro, login, OTP por email, validação de idade |
| 04 | `04-chaves-de-api.md` | Geração, hash, exibição única, validação, revogação |
| 05 | `05-endpoints-da-api.md` | Contratos dos endpoints (web e API pública) |
| 06 | `06-pipeline-de-deteccao.md` | DNS, WHOIS, atributos, imagens, prompts, ensemble |
| 07 | `07-interface-web.md` | Telas, fluxos e textos obrigatórios |
| 08 | `08-seguranca-rate-limit-observabilidade.md` | Segurança, limites, logs, métricas |
| 09 | `09-testes-e-deploy.md` | Estratégia de testes, CI/CD, ambientes, fases |
| 10 | `10-pendencias-e-decisoes.md` | Decisões tomadas, conflitos nos requisitos e itens em aberto |

## Requisitos (resumo)

1. Cadastro e login na plataforma web com **email + senha + OTP enviado por email**.
2. Acesso aos endpoints reais da API **sempre com chave de API** (web ou curl).
3. Chave gerada uma única vez, **armazenada apenas como hash**, com aviso explícito de que será exibida só uma vez.
4. Supabase para autenticação e banco; **todos os ids são UUID**.
5. Usuário: `username`, `first_name`, `last_name`, `full_name`, `birth_date`, `email`, senha; chave só liberada para maiores de 18 anos.
6. Consulta de detecção recebe **apenas o nome do domínio** (web e API).
7. Internamente: DNS + WHOIS + atributos → imagens + prompts de texto + atributos → ensemble multimodal. Detalhes técnicos virão por arquivos de contexto.

## Ponto de atenção crítico

O requisito "ao logar, a chave de API é recuperada automaticamente" **conflita** com "chave só em hash e exibida uma vez": um hash não pode ser revertido. A solução adotada está em `04-chaves-de-api.md` (seção "Acesso web") e registrada em `10-pendencias-e-decisoes.md`.
