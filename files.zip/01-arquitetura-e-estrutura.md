# 01 — Arquitetura e Estrutura

## Componentes

```
[Navegador / SPA React] ──JWT Supabase──┐
                                        ▼
[curl / código cliente] ──X-API-Key──► [API FastAPI] ──► Supabase (Auth + Postgres)
                                        │
                                        ├─► Serviço de Coleta (DNS, WHOIS/RDAP)
                                        ├─► Serviço de Atributos
                                        ├─► Geradores (imagens, prompts)
                                        └─► Motor de Inferência (ensemble multimodal)
```

- **SPA web**: cadastro, login com OTP, painel da chave, tela de consulta.
- **API (FastAPI)**: valida credenciais (JWT ou chave), aplica limites, orquestra o pipeline.
- **Supabase**: Auth (usuário, senha, OTP por email) e Postgres (perfil, chaves, logs, cache).
- **Pipeline de detecção**: módulo interno, desacoplado da camada HTTP, para poder virar worker separado.

## Stack proposta

| Camada | Escolha | Observação |
|--------|---------|------------|
| API | Python 3.11+, FastAPI, Uvicorn | async nativo |
| Acesso ao BD | `asyncpg` (dados) + `supabase-py` (Auth) | |
| Frontend | React + Vite + TypeScript, `@supabase/supabase-js` | |
| DNS | `dnspython` (resolver async) | |
| WHOIS | RDAP primeiro, `python-whois` como fallback | |
| Normalização | `tldextract`, `idna` | |
| Modelos | PyTorch, HuggingFace Transformers, scikit-learn/XGBoost | detalhes em contexto posterior |
| Cache/limites | Postgres no MVP; Redis se necessário | |
| Email OTP | SMTP customizado no Supabase (Resend/SES) | |

## Estrutura de pastas

```
repo/
├── api/
│   ├── app/
│   │   ├── main.py
│   │   ├── core/            # config, segurança, logging, erros
│   │   ├── db/              # pool asyncpg, queries, migrations/
│   │   ├── auth/            # rotas web: signup, login, otp, me
│   │   ├── keys/            # geração, hash, validação, revogação
│   │   ├── deps/            # dependências: get_current_user, require_api_key
│   │   ├── domains/         # rotas /v1/domains, schemas, normalização
│   │   ├── pipeline/
│   │   │   ├── collectors/  # dns.py, whois.py
│   │   │   ├── features/    # cálculo de atributos
│   │   │   ├── renderers/   # imagens (GASF etc.), prompts de texto
│   │   │   └── inference/   # carregamento de modelos, ensemble
│   │   └── ratelimit/
│   ├── tests/
│   └── pyproject.toml
├── web/                     # SPA React
├── supabase/
│   ├── migrations/
│   └── templates/           # templates de email OTP
└── docs/                    # estes .md
```

## Princípios

1. Camada HTTP fina; regra de negócio em serviços testáveis.
2. Modelos carregados **uma vez** no startup (lifespan), nunca por requisição.
3. Toda I/O externa (DNS, WHOIS) com timeout e tratamento de falha parcial.
4. Segredos apenas por variáveis de ambiente; `service_role` jamais exposta ao frontend.
5. Todos os ids em UUID (`uuid`/`gen_random_uuid()`); nunca expor inteiros sequenciais.

## Variáveis de ambiente (mínimo)

`SUPABASE_URL`, `SUPABASE_ANON_KEY`, `SUPABASE_SERVICE_ROLE_KEY`, `SUPABASE_JWT_SECRET`, `DATABASE_URL`, `API_KEY_PEPPER`, `MODEL_DIR`, `DNS_TIMEOUT_S`, `WHOIS_TIMEOUT_S`, `ALLOWED_ORIGINS`.
