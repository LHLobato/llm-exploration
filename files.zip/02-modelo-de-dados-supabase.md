# 02 — Modelo de Dados (Supabase / Postgres)

Regra global: **toda PK e FK é `uuid`**. Senha e OTP ficam sob responsabilidade do Supabase Auth (`auth.users`), não em tabelas próprias.

## Tabelas

### `public.profiles` (1:1 com `auth.users`)

```sql
create table public.profiles (
  id            uuid primary key references auth.users(id) on delete cascade,
  username      citext not null unique,
  first_name    text   not null,
  last_name     text   not null,
  full_name     text   generated always as (first_name || ' ' || last_name) stored,
  birth_date    date   not null,
  email         citext not null unique,
  is_adult      boolean generated always as
                (birth_date <= (current_date - interval '18 years')) stored,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  constraint username_format check (username ~ '^[a-z0-9_]{3,30}$')
);
```

Observações:
- `is_adult` com coluna gerada **não funciona** como `stored` (depende de `current_date`, não imutável). Implementar como **view** ou função `is_adult(birth_date)`; a verificação real é feita no backend e dentro da função de criação de chave.
- O requisito "otp" no usuário é atendido pelo Supabase Auth; **não armazenar OTP** no perfil.
- `full_name` pode ser gerado ou calculado na aplicação; se `first_name`/`last_name` forem a fonte, manter coluna gerada.

### `public.api_keys`

```sql
create table public.api_keys (
  id           uuid primary key default gen_random_uuid(),
  user_id      uuid not null references public.profiles(id) on delete cascade,
  name         text not null default 'default',
  key_prefix   text not null,            -- ex.: "dmd_a1b2c3d4" (identificação, não secreto)
  key_hash     bytea not null unique,    -- HMAC-SHA256(pepper, chave completa)
  status       text not null default 'active'
               check (status in ('active','revoked','expired')),
  last_used_at timestamptz,
  expires_at   timestamptz,
  created_at   timestamptz not null default now(),
  revoked_at   timestamptz
);
create unique index one_active_key_per_user
  on public.api_keys(user_id) where status = 'active';
create index on public.api_keys(key_prefix);
```

### `public.api_requests` (auditoria e quota)

```sql
create table public.api_requests (
  id          uuid primary key default gen_random_uuid(),
  api_key_id  uuid not null references public.api_keys(id) on delete cascade,
  user_id     uuid not null references public.profiles(id) on delete cascade,
  channel     text not null check (channel in ('web','api')),
  domain      text,
  status_code int  not null,
  latency_ms  int,
  created_at  timestamptz not null default now()
);
create index on public.api_requests(api_key_id, created_at desc);
```

### `public.domain_analyses` (resultado + cache)

```sql
create table public.domain_analyses (
  id             uuid primary key default gen_random_uuid(),
  domain         text not null,                 -- normalizado (punycode, minúsculo)
  registered_domain text not null,
  label          text check (label in ('malicious','benign')),
  score          real,                          -- probabilidade da classe maliciosa
  model_version  text not null,
  features       jsonb,
  evidence       jsonb,                         -- DNS/WHOIS resumidos
  partial        boolean not null default false,
  created_at     timestamptz not null default now(),
  expires_at     timestamptz not null
);
create index on public.domain_analyses(domain, model_version, expires_at desc);
```

Resultado é **global** (não por usuário); a relação usuário↔consulta fica em `api_requests`.

### `public.otp_audit` (opcional)

Registro de tentativas/envios de OTP (user_id nullable, email_hash, evento, ip, created_at) para detecção de abuso. Não guarda o código.

## RLS (Row Level Security)

- `profiles`: `select/update` apenas onde `id = auth.uid()`; `insert` via trigger/backend.
- `api_keys`: `select` do próprio usuário (sem expor `key_hash` — usar view sem a coluna); `insert/update` somente via função `security definer` ou backend com `service_role`.
- `api_requests`: `select` do próprio usuário; escrita só pelo backend.
- `domain_analyses`: sem acesso direto do cliente; leitura/escrita só backend.

## Trigger de criação de perfil

Trigger em `auth.users` (`after insert`) lê `raw_user_meta_data` (username, first_name, last_name, birth_date) e cria a linha em `profiles`; falha se `birth_date` ausente. Alternativa: backend cria o perfil após confirmação do OTP (preferível para validar unicidade de username com mensagem clara).

## Migrations

Versionadas em `supabase/migrations/` (`supabase migration new ...`), aplicadas por CI. Extensões: `citext`, `pgcrypto`.
