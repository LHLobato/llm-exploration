# 05 — Endpoints

Base: `/v1`. JSON UTF-8. Ids sempre UUID. Erros no formato:

```json
{ "error": { "code": "invalid_domain", "message": "...", "request_id": "uuid" } }
```

## Autenticação por endpoint

| Grupo | Credencial |
|-------|-----------|
| `/auth/*` | nenhuma (com rate limit) |
| `/me`, `/keys/*` | JWT Supabase (sessão web) |
| `/v1/domains/*` | **chave de API** (`X-API-Key`) ou JWT web (resolve a chave do usuário — doc 04) |

## Auth (plataforma web)

Ver doc 03. Respostas resumidas:

- `POST /auth/signup` → `202 {otp_required:true}`
- `POST /auth/signup/verify` → `200 {session}`
- `POST /auth/login` → `200 {otp_required:true}`
- `POST /auth/login/verify` → `200 {session}`

## Usuário e chaves

| Método | Rota | Descrição |
|--------|------|-----------|
| GET | `/me` | perfil + estado da chave (sem segredo) |
| POST | `/keys` | gera chave (≥18 anos), retorna texto puro uma vez |
| GET | `/keys` | lista metadados (prefixo, status, last_used_at) |
| POST | `/keys/{id}/rotate` | rotaciona |
| DELETE | `/keys/{id}` | revoga |

## Detecção de domínio malicioso

### `POST /v1/domains/analyze`

Request — **apenas o nome do domínio**:

```json
{ "domain": "exemplo.com.br" }
```

Equivalente curl:

```bash
curl -X POST https://api.exemplo.com/v1/domains/analyze \
  -H "X-API-Key: dmd_..." -H "Content-Type: application/json" \
  -d '{"domain":"exemplo.com.br"}'
```

Validação de entrada (`400 invalid_domain`):
- Rejeitar URLs (`http://`, caminho, query, porta), IPs, espaços, e-mails, wildcards.
- Normalizar: minúsculas, remover ponto final, IDN → punycode (`idna`), validar rótulos (≤63) e total (≤253).
- Exigir sufixo público válido (`tldextract` com lista PSL atualizada); calcular `registered_domain`.

Response `200`:

```json
{
  "id": "uuid",
  "domain": "exemplo.com.br",
  "registered_domain": "exemplo.com.br",
  "verdict": "benign",
  "score": 0.03,
  "model_version": "ens-2026.11.0",
  "partial": false,
  "evidence": { "dns": {...}, "whois": {...}, "notes": [] },
  "cached": false,
  "analyzed_at": "2026-11-06T12:00:00Z"
}
```

- `partial=true` quando DNS/WHOIS falham parcialmente e o modelo opera com atributos ausentes (política de imputação definida no doc 06).
- `cached=true` quando reutiliza análise dentro do TTL.
- `504 upstream_timeout` se o orçamento de tempo estourar sem resultado utilizável.

### `POST /v1/domains/analyze/batch` (fase 2)

Lista de até N domínios; retorna `202 {job_id}`; `GET /v1/jobs/{id}` consulta progresso/resultados.

### `GET /v1/domains/analyses/{id}`

Recupera análise por UUID (somente se a requisição pertence ao mesmo usuário/chave).

## Cabeçalhos de resposta

`X-Request-Id`, `X-RateLimit-Limit`, `X-RateLimit-Remaining`, `X-RateLimit-Reset`, `Retry-After` (em 429).

## Códigos de status

`200`, `201`, `202`, `400`, `401`, `403` (`age_restricted`, `key_revoked`), `404`, `422`, `429`, `500`, `504`.

## Versionamento e OpenAPI

Prefixo `/v1`; mudanças incompatíveis → `/v2`. Documentação OpenAPI gerada pelo FastAPI, com esquema de segurança `ApiKeyAuth` (header `X-API-Key`).
