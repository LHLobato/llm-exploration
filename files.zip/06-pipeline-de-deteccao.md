# 06 — Pipeline de Detecção

> Os detalhes técnicos (lista de atributos, formatos de imagem, template de prompt, modelos e pesos do ensemble) serão fornecidos **por arquivos de contexto**. Este documento define a estrutura, as interfaces e as garantias; os pontos marcados **[CONTEXTO]** aguardam essas especificações.

## Visão geral

```
domínio normalizado
   │
   ├─► Coleta: DNS ─┐
   └─► Coleta: WHOIS ┤
                     ▼
              Atributos (numéricos/categóricos/lexicais)   [CONTEXTO]
                     │
     ┌───────────────┼────────────────┐
     ▼               ▼                ▼
 Imagens        Prompt de texto   Vetor de atributos
 [CONTEXTO]     [CONTEXTO]
     │               │                │
     └───────► Ensemble multimodal ◄──┘   [CONTEXTO]
                     │
             veredito + score + evidências
```

## 1. Coleta

Interface comum:

```python
class Collector(Protocol):
    async def collect(self, ctx: DomainContext) -> CollectorResult: ...
# CollectorResult: data: dict | None, ok: bool, error: str | None, elapsed_ms: int
```

### DNS (`collectors/dns.py`)
- `dnspython` async; registros previstos: A, AAAA, NS, MX, TXT, SOA, CNAME (+ TTLs). Lista final **[CONTEXTO]**.
- Resolvers configuráveis, timeout por consulta, 1–2 tentativas, execução concorrente (`asyncio.gather`).
- Distinguir `NXDOMAIN`, `NoAnswer`, timeout e SERVFAIL (cada um é informação, não só erro).
- Enriquecimento opcional (país/ASN do IP) via base local (MaxMind/ipinfo) — **[CONTEXTO]**.

### WHOIS (`collectors/whois.py`)
- Tentar **RDAP** (JSON estruturado) e cair para WHOIS clássico; sempre sobre o `registered_domain`.
- Extrair: datas (criação, atualização, expiração), registrar, status, nameservers, país, privacidade.
- Respeitar rate limits dos servidores; cache de WHOIS com TTL longo (ex.: 24 h).
- Campos ausentes/redigidos (GDPR) são comuns → tratar como ausentes, não erro.

### Garantias
- **Nenhuma conexão HTTP ao domínio consultado** no MVP (somente DNS/WHOIS), evitando SSRF e execução de conteúdo malicioso. Se coleta de página/screenshot for exigida, isolar em sandbox sem acesso à rede interna.
- Orçamento de tempo global por requisição (ex.: 8 s); tarefas canceladas ao estourar.
- Falha parcial → `partial=true`; política de ausentes (imputação/indicadores `is_missing`) alinhada ao treino **[CONTEXTO]**.

## 2. Atributos (`features/`)

- Módulo puro e determinístico: `compute_features(ctx, dns, whois) -> FeatureVector`.
- Famílias previstas: lexicais do nome (comprimento, entropia, razão de dígitos, n-gramas), DNS, WHOIS (idade do domínio, tempo para expirar), rede. Definição exata **[CONTEXTO]**.
- **Paridade treino/inferência**: reutilizar o *mesmo código* de extração do treino (pacote compartilhado) e fixar versão de scalers/encoders/TF-IDF serializados junto ao modelo.
- Testes com vetores dourados (domínio → vetor esperado).

## 3. Geração de imagens (`renderers/images.py`)

- Converte o vetor de atributos em imagem(ns) (tipo, tamanho e normalização **[CONTEXTO]**).
- Funções puras, em memória (sem disco); saída como tensor pronto para o modelo.
- Cache por hash do vetor quando útil.

## 4. Geração de prompts (`renderers/prompts.py`)

- Template de texto com campos etiquetados a partir dos atributos/evidências **[CONTEXTO]**.
- Escapar/limitar tamanho; truncar de forma determinística; tokenizer da mesma versão do treino.
- **Sanitização**: o domínio e campos WHOIS/TXT são controlados por terceiros → tratar como dado não confiável (sem interpolação em instruções livres; manter formato rígido tagueado).

## 5. Inferência (`inference/`)

- `ModelRegistry` carrega no startup: modelo(s) de imagem, de texto e de atributos, e o combinador do ensemble **[CONTEXTO]**.
- Interface: `predict(features, image, prompt) -> {score, per_model_scores}`.
- Execução em threadpool/`run_in_executor` (ou worker dedicado) para não bloquear o event loop; *batching* opcional para batch endpoint.
- Hardware: definir CPU vs GPU, quantização e *warm-up* com amostra sintética.
- Limiar de decisão configurável e versionado (`threshold`), com `model_version` em toda resposta.
- Degradação: se uma modalidade falhar, política definida (ex.: ensemble reduzido + `partial=true`) **[CONTEXTO]**.

## 6. Cache e persistência

- Chave de cache: `(registered_domain|domain, model_version)`; TTL curto para maliciosos recentes, maior para benignos (valores configuráveis).
- Resultado gravado em `domain_analyses`; consulta registrada em `api_requests`.

## 7. Contrato de saída

`verdict`, `score`, `model_version`, `partial`, `evidence` (resumo DNS/WHOIS, sem PII), opcionalmente `explanations` (fase futura).

## Checklist de entrada de contexto

Para fechar este documento, receber: lista de atributos e ordem; registros DNS/campos WHOIS; tipos/tamanhos das imagens; template de prompt; modelos, pesos e artefatos (scalers, tokenizers); estratégia do ensemble; limiar; política de dados ausentes; requisitos de latência e hardware.
