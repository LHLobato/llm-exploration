# 07 — Interface Web

SPA React + Vite + TypeScript, `@supabase/supabase-js` para sessão, cliente HTTP único com interceptador (JWT, erros, `request_id`).

## Telas e fluxos

1. **Cadastro** — username, nome, sobrenome, data de nascimento, email, senha (+ confirmação, indicador de força). Validação em tempo real (username disponível, senha). Nota clara de que a chave de API só é liberada para maiores de 18 anos.
2. **Verificação de OTP (cadastro)** — 6 campos, reenvio com contador (60 s), mensagens de erro/expirado.
3. **Login** — email + senha → tela de OTP → painel.
4. **Recuperar senha** — email → OTP → nova senha.
5. **Painel** (pós-login)
   - Carrega `GET /me`.
   - Estado da chave: *ativa* (mostra prefixo, criada em, último uso), *inexistente*, *revogada*, *restrita por idade*.
   - Ações: gerar, rotacionar, revogar (com confirmação).
6. **Modal de geração de chave** — exibe a chave completa **uma única vez** com o aviso destacado do doc 04, botão copiar, checkbox "já copiei", bloqueio de fechamento sem confirmar.
7. **Consulta de domínio** — campo único (apenas nome do domínio), validação local equivalente à do servidor, exibição de veredito, score, evidências e aviso de resultado parcial. Usa o JWT; o backend resolve e valida a chave (doc 04).
8. **Documentação / exemplos** — trechos `curl`, Python e JS com `X-API-Key`, e link para OpenAPI.
9. **Uso** — contagem de requisições, limite restante, últimas consultas.

## Comportamentos obrigatórios

- Ao logar, chamar `/me` e validar o estado da chave automaticamente; se não houver chave ativa, a consulta fica desabilitada com CTA para gerar (ou mensagem de restrição de idade).
- A chave em texto puro vive só no estado do modal, é limpa ao fechar e nunca é persistida.
- Mensagens de erro de login genéricas; sem enumeração de contas.
- Acessibilidade (WCAG AA), responsivo, textos em PT-BR (i18n preparado).
- Proteções: CSP restritiva, sem `dangerouslySetInnerHTML`, `autocomplete` correto nos campos.

## Estrutura do frontend

```
web/src/
├── api/          # cliente HTTP, tipos gerados do OpenAPI
├── auth/         # contexto de sessão, guards de rota
├── pages/        # Signup, VerifyOtp, Login, Dashboard, Analyze, Docs, Usage
├── components/   # OtpInput, KeyOnceModal, DomainResultCard
└── lib/          # validação de domínio, formatadores
```
