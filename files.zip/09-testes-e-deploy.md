# 09 — Testes, Deploy e Fases

## Estratégia de testes

| Nível | Foco |
|-------|------|
| Unitário | normalização de domínio, hash/validação de chave, cálculo de idade, atributos (vetores dourados), prompts |
| Integração | fluxo signup→OTP→perfil; login em duas etapas; geração de chave; RLS no Supabase local |
| Contrato | OpenAPI como fonte da verdade; testes de schema (schemathesis) |
| Pipeline | DNS/WHOIS com respostas gravadas (VCR/mocks); falhas parciais e timeouts |
| Modelo | paridade treino/inferência em amostra fixa; *smoke test* de latência |
| Segurança | enumeração de contas, rate limit, vazamento de segredos em logs, SSRF |
| E2E | Playwright: cadastro, login com OTP, gerar chave (aviso único), consulta |

Ambiente de testes: `supabase start` (stack local) com Inbucket para capturar emails de OTP.

## Ambientes

`local` (Supabase CLI) → `staging` (projeto Supabase separado) → `production`. Migrations aplicadas por CI; segredos por ambiente.

## CI/CD

1. Lint/format (ruff, mypy; eslint, tsc).
2. Testes unitários e de integração.
3. Build de imagem Docker da API (modelos baixados de storage versionado, não embutidos no git).
4. Deploy em staging + E2E; promoção manual para produção.

## Fases de implementação

**Fase 0 — Fundação**: repo, estrutura, CI, Supabase local, migrations base (`profiles`).

**Fase 1 — Autenticação**: signup/login com OTP, SMTP, perfil, regra de idade, telas.

**Fase 2 — Chaves**: tabela, geração/hash, modal de exibição única, `require_api_key`, `/me`, revogação.

**Fase 3 — Endpoint com stub**: `/v1/domains/analyze` com validação de domínio, rate limit, logs e resposta simulada (contrato final).

**Fase 4 — Pipeline real**: coleta DNS/WHOIS, atributos, imagens, prompts, ensemble (após receber os arquivos de contexto).

**Fase 5 — Endurecimento**: cache, batch/jobs, métricas, testes de carga, revisão de segurança e LGPD.

## Critérios de aceite do MVP

- Cadastro e login funcionam apenas com OTP válido.
- Menor de 18 anos não consegue gerar chave (UI e API).
- Chave exibida uma única vez; BD contém só hash.
- Nenhum endpoint `/v1/domains/*` responde sem chave válida (curl) ou sessão com chave ativa (web).
- Entrada aceita apenas nome de domínio; demais formatos retornam `400`.
- Resposta p95 dentro da meta definida após o contexto técnico (a definir).
