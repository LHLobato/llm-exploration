# 10 — Decisões, Conflitos e Pendências

## Decisões tomadas neste plano

| # | Decisão | Motivo |
|---|---------|--------|
| D1 | Chave com HMAC-SHA256 + pepper (não bcrypt) | segredo de alta entropia; validação rápida por requisição |
| D2 | Web usa JWT e o backend resolve/valida a chave ativa do usuário | hash é irreversível; evita guardar a chave em texto |
| D3 | Login em duas etapas (senha → OTP) sem emitir sessão na etapa 1 | Supabase não tem senha+OTP email nativo |
| D4 | Uma chave ativa por usuário no MVP | simplicidade; configurável depois |
| D5 | Menor de 18 pode ter conta, mas não chave | requisito fala em "disponibilização de chave" |
| D6 | Sem conexões HTTP ao domínio consultado | segurança (SSRF/conteúdo malicioso) |
| D7 | Análise cacheada por `(domínio, model_version)` | custo e latência |

## Conflitos/ambiguidades nos requisitos

1. **"Chave recuperada automaticamente ao logar" × "hash + exibida uma vez"** — resolvido por D2. Confirmar se é aceitável que a web não use a chave em texto.
2. **"A chave deve ser informada sempre" no navegador** — interpretado como "toda consulta web fica vinculada a uma chave válida do usuário", não como o usuário digitar a chave.
3. **Campo `otp` no usuário** — OTP é efêmero e gerido pelo Supabase; não será coluna do perfil.
4. **`is_adult` como coluna gerada** — não é possível (função não imutável); usar função/view.
5. **OTP no login além da senha** — confirmar se é segundo fator (D3) ou substitui a senha após o cadastro.

## Pendências (aguardam arquivos de contexto)

- Lista e ordem dos atributos; registros DNS e campos WHOIS usados.
- Tipos e dimensões das imagens; template de prompt.
- Modelos, artefatos serializados e estratégia do ensemble; limiar de decisão.
- Política para dados ausentes e para degradação de modalidades.
- Metas de latência e hardware de inferência (CPU/GPU).

## Perguntas em aberto para o produto

- Limites/planos de uso por chave? Haverá mais de uma chave por usuário?
- Menores: apenas bloqueio de chave ou bloqueio de cadastro?
- Idiomas da interface e dos emails (apenas PT-BR?)
- Retenção de histórico de consultas e política de exclusão (LGPD).
- Endpoint em lote e exportação de resultados entram no MVP?
- Provedor de email transacional preferido (Resend, SES, outro).
